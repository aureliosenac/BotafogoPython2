import json
from funcionarios import Funcionario

ARQUIVO_JSON = r"C:\Users\47129532024.4\Documents\Aula dia 25-11-24\funcionarios.json"

def carregar_funcionarios():
    try:
        with open(ARQUIVO_JSON, 'r') as file:
            dados = json.load(file)
            return [Funcionario(**f) for f in dados]
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def salvar_funcionarios(funcionarios):
    with open(ARQUIVO_JSON, 'w') as file:
        json.dump([f.__dict__ for f in funcionarios], file, indent=4)

def listar_funcionarios(funcionarios):
    if funcionarios:
        print("\nFuncionários cadastrados:")
        for i, funcionario in enumerate(funcionarios, start=1):
            print(f"{i}. {funcionario}")
    else:
        print("\nNenhum funcionário cadastrado.")

def cadastrar_funcionario():
    nome = input("Nome do funcionário: ").strip()
    idade = int(input("Idade do funcionário: "))
    cargo = input("Cargo do funcionário: ").strip()
    return Funcionario(nome, idade, cargo)

def menu():
    funcionarios = carregar_funcionarios()
    while True:
        print("\nMenu Principal:")
        print("1. Cadastrar um novo funcionário")
        print("2. Listar todos os funcionários")
        print("3. Salvar funcionários em arquivo JSON")
        print("4. Sair do programa")
        opcao = input("Escolha uma opção: ")

        if opcao == '1':
            funcionario = cadastrar_funcionario()
            funcionarios.append(funcionario)
            print("\nFuncionário cadastrado com sucesso!")
        elif opcao == '2':
            listar_funcionarios(funcionarios)
        elif opcao == '3':
            salvar_funcionarios(funcionarios)
            print("\nFuncionários salvos no arquivo JSON.")
        elif opcao == '4':
            salvar_funcionarios(funcionarios)
            print("\nSaindo do programa. Dados salvos!")
            break
        else:
            print("\nOpção inválida! Tente novamente.")

if __name__ == "__main__":
    menu()
